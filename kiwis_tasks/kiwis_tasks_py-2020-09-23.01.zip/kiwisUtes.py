import pandas as pd
import requests
import sys
from io import StringIO

# intranet server - 2020-08-14
base_url = 'http://amaprdwiskweb1b:8081/KiWIS/KiWIS?'


class kiwisUtes:

    def __init__(self):
        self.base_url = base_url


    def _csv2df(self, csvresponse):
        df = pd.read_csv(StringIO(csvresponse), sep=';', header=None, names=['key', 'values'])

        #start by making df for first timeseries
        ts=df.iloc[0]['values']
        numrows=int(df.iloc[1]['values'])
        di=3 #assuming data starts here - ie minimal metadata
        df1=pd.DataFrame({'dates': df.loc[di:di+numrows-1,'key'], ts:df.loc[di:di+numrows-1,'values']} )
        df1[ts]=df1[ts].astype(float)
        #then add(join) the rest of timeseries on df at time till done
        i=di+numrows
        maxi=len(df.index) #total number of rows
        while i<maxi:
            ts=df.iloc[i]['values']
            numrows=int(df.iloc[i+1]['values'])
            di=i+3 #di is index to start of data rows
            df_next=pd.DataFrame({'dates': df.loc[di:di+numrows-1,'key'], ts:df.loc[di:di+numrows-1,'values']} )
            df_next[ts]=df_next[ts].astype(float)
            #join on dates then release index ready for next itteration
            df1 = df1.set_index('dates').join(df_next.set_index('dates'), how='outer')
            df1=df1.reset_index()
            i=i+numrows+3
        return df1

    def z_csv2df(self, csvresponse):
        df = pd.read_csv(StringIO(csvresponse), sep=';', header=None, names=['key', 'values'])
        df2 = pd.DataFrame(index=df['key'].drop_duplicates())
        uniqlen = df2.shape[0]
        # make a wide df from vertical
        ts=df.iloc[0]['values']
        numrows=int(df.iloc[1]['values'])
        df_col=pd.DataFrame({'dates': df.loc[3:2+numrows,'key'], ts:df.loc[3:2+numrows,'values']} )
        pd.concat([df2, df_col])
        df_col.set_index('dates')
        df.loc[1:numrows,'values']

        for i in range(0, df.shape[0], uniqlen):
            df2[i] = df.loc[i:i+uniqlen-1, 'values'].values
        # keep just the data
        df2.drop(index=['#ts_id', '#rows', '#Timestamp'], inplace=True)
        # and convert the strings to numberic so can manipulate numbers
        for i in range(df2.shape[1]):
            df2.iloc[:, i] = df2.iloc[:, i].astype(float)

        return (df2)

    def get_ts_list(self, requested_ts_path):
        """
        get the timeseries for the specified ts_path
        and return a dataframe
        """
        payload = {
            'service': 'kisters',
            'type': 'queryServices',
            'request': 'getTimeseriesList',
            'datasource': '0',
            'returnfields': 'ts_path,site_no,station_no,stationparameter_no,ts_shortname',
            'format': 'html',
            'ts_path': requested_ts_path
        }

        try:
            self.response = requests.get(self.base_url, params=payload)
            html = self.response.text
            listdf = pd.read_html(html)  # read_html returns a list of df's.
            df = listdf[0]  # just want first
        except:
            e = sys.exc_info()[0]
            print("Exception: %s" % str(e))
            sys.exit()

        headers = [s.strip() for s in df.iloc[0]]
        df.columns = headers
        df.drop(axis=0, index=0, inplace=True)
        df.dropna(inplace=True)
        return df

    def get_tsvalues_list_ts_paths(self,  startdate, enddate, list_ts_paths,):
        """
        get the timeseries values given a list of ts_path's
        and a date start and end
        and return a dataframe
        """
        df = pd.DataFrame()

        for ts_path in list_ts_paths:
            payload = {
                'service': 'kisters',
                'type': 'queryServices',
                'datasource': '0',
                'request': 'getTimeseriesValues',
                'format': 'csv',
                'ts_path': ts_path,
                'from': startdate,
                'to': enddate,
                'dateformat': 'yyyy-MM-dd'
            }

            try:
                self.response = requests.get(self.base_url, params=payload)
                csv = self.response.text  
            except:
                e = sys.exc_info()[0]
                print("Exception: %s" % str(e))
                sys.exit()
                
            df_i = self._csv2df(csv)
            df = pd.concat([df, df_i], axis=1, sort=False)
        # next ts_path
        # now some final minipulation and exports
        df.to_csv('z_outputraw.csv')
        df=df.set_index('dates')
        df2 = df.sum(axis=1)
        df2=df2.reset_index()
        df2.rename(columns={0:'values'}, inplace=True)
        
        df2.to_csv('z_outputsum.csv')
        # tart up the df
        #df3 = df2.reset_index()
        #df3.rename(columns={'key': 'date', 0: 'values'}, inplace=True)
        return df2
